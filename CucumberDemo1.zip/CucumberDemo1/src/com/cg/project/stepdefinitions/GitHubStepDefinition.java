package com.cg.project.stepdefinitions;

import org.junit.Assert;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;
import com.cg.github.pagebeans.LoginPage;

import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class GitHubStepDefinition {
	private WebDriver driver1;
	private LoginPage loginPage;
	@Before
	public void setUpStepEnv() {
		System.setProperty("webdriver.chrome.driver", "D:\\3000152_Shreyansh_Jain\\chromeDriver.exe");

	}
	@Given("^User is on GitHubLoginPage$")
	public void user_is_on_GitHubLoginPage() throws Throwable {

	    driver1=new ChromeDriver();
	    driver1.get("https://github.com/login");
	    loginPage=PageFactory.initElements(driver1,LoginPage.class);
	}
	@When("^user enter Invalid username and passwords$")
	public void user_enter_Invalid_username_and_passwords() throws Throwable {
	    loginPage.setUsername("");
	    loginPage.setPassword("");
	    loginPage.clickSignIn();
	}

	@Then("^Incorrect 'username or password' Message should display$")
	public void incorrect_username_or_password_Message_should_display() throws Throwable {
	    String expectedErrorMessage="Incorrect username or password.";
	    Assert.assertEquals(expectedErrorMessage, loginPage.getActualMessage());
	}

	@When("^user enter valid username and password$")
	public void user_enter_valid_username_and_password() throws Throwable {
		 loginPage.setUsername("shreyans281997");
		    loginPage.setPassword("jain.028");
		    loginPage.clickSignIn();
	}

	@Then("^user should successfully sign in on his github page$")
	public void user_should_successfully_sign_in_on_his_github_page() throws Throwable {
	    Assert.assertEquals("GitHub", driver1.getTitle());
	    
	}
//	@After
//  public void tearDownStepEnv() {
//		driver1.switchTo().alert().dismiss();
//		driver1.close();
//  }

}
