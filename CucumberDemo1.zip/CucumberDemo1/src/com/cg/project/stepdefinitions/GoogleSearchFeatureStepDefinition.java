package com.cg.project.stepdefinitions;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;


public class GoogleSearchFeatureStepDefinition {
	WebDriver driver11;
	@Given("^user is on google home page$")
	public void user_is_on_google_home_page() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "D:\\3000152_Shreyansh_Jain\\chromeDriver.exe");
		driver11=new ChromeDriver();
		driver11.get("http:\\www.google.co.in");
	}

	@When("^user search for 'agile methodology'$")
	public void user_search_for_agile_methodology() throws Throwable {
		WebElement searchElement=driver11.findElement(By.name("q"));
		searchElement.sendKeys("Agile Methodology");
        searchElement.submit();
	}

	@Then("^All links should display with 'agile methodology'$")
	public void all_links_should_display_with_agile_methodology() throws Throwable {
		String actualTitle=driver11.getTitle();
		String expectedTitle="Agile Methodology - Google Search";
		Assert.assertEquals(expectedTitle, actualTitle);
	}
}
