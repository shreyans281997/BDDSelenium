package com.cg.project.stepdefinitions;
import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;
import com.cg.github.pagebeans.RegistrationPageBean;
import cucumber.api.PendingException;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class RegistrationFeatureStepDefinition {
	private WebDriver driver;
	private RegistrationPageBean pageBean;
	@Before
	public void setUpStepEnv() {
		System.setProperty("webdriver.chrome.driver", "D:\\3000152_Shreyansh_Jain\\chromeDriver.exe");
	}
	@Given("^User is accessing RegistrationPage on Browser$")
	public void user_is_accessing_RegistrationPage_on_Browser() throws Throwable {
		driver=new ChromeDriver();

		driver.get("D:\\Users\\ADM-IG-HWDLAB1D\\Downloads\\WebPages\\RegistrationForm.html");
		pageBean=PageFactory.initElements(driver, RegistrationPageBean.class);

	}

	@When("^user is trying to submit data without entering 'User Id'$")
	public void user_is_trying_to_submit_data_without_entering_User_Id() throws Throwable {
		pageBean.clickSignUp();
	}

	@Then("^'User Id should not be empty/length bebetween (\\d+) to (\\d+)' alert message should display$")
	public void user_Id_should_not_be_empty_length_bebetween_to_alert_message_should_display(int arg1, int arg2) throws Throwable {
		String expectedAlertMessage="User Id should not be empty / length be between 5 to 12";
		String actualAlertMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedAlertMessage, actualAlertMessage);
	}

	@When("^user is trying to submit request without entering name$")
	public void user_is_trying_to_submit_request_without_entering_name() throws Throwable {
		driver.switchTo().alert().dismiss();
		pageBean.setUserId("shrey1234");
		pageBean.clickSignUp();
	}

	@Then("^'Name should not be empty and must have alphabet characters only'$")
	public void name_should_not_be_empty_and_must_have_alphabet_characters_only() throws Throwable {
		String expectedAlertMessage="Username should not be empty and must have alphabet characters only";
		String actualAlertMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedAlertMessage, actualAlertMessage);
	}

	@When("^User is trying to submit request without entering 'Password'$")
	public void user_is_trying_to_submit_request_without_entering_Password() throws Throwable {
		driver.switchTo().alert().dismiss();
		pageBean.setUsername("shreyansh");
		pageBean.clickSignUp();
	}

	@Then("^'Password should not be empty/length be between (\\d+) to (\\d+)'$")
	public void password_should_not_be_empty_length_be_between_to(int arg1, int arg2) throws Throwable {
		String expectedAlertMessage="Password should not be empty / length be between 7 to 12";
		String actualAlertMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedAlertMessage, actualAlertMessage);

	}

	@When("^user is trying to submit request without entering address$")
	public void user_is_trying_to_submit_request_without_entering_address() throws Throwable {
		driver.switchTo().alert().dismiss();
		pageBean.setPassword("hellorey");
		//  pageBean.setAddress("123@");
		pageBean.clickSignUp();
	}

	@Then("^'User address must have alphanumeric characters only'$")
	public void user_address_must_have_alphanumeric_characters_only() throws Throwable {
		String expectedAlertMessage="User address must have alphanumeric characters only";
		String actualAlertMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedAlertMessage, actualAlertMessage);
	}

	@When("^user is trying to submit request without selecting country$")
	public void user_is_trying_to_submit_request_without_selecting_country() throws Throwable {
		driver.switchTo().alert().dismiss();
		pageBean.setAddress("gtggd");
		pageBean.clickSignUp();

	}

	@Then("^'Select your country from the list'$")
	public void select_your_country_from_the_list() throws Throwable {
		String expectedAlertMessage="Select your country from the list";
		String actualAlertMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedAlertMessage, actualAlertMessage);
	}

	@When("^User is trying to submit request without entering valid 'zipCode$")
	public void user_is_trying_to_submit_request_without_entering_valid_zipCode() throws Throwable {
		driver.switchTo().alert().dismiss();
		pageBean.setCountry("India");
		pageBean.clickSignUp();
	}

	@Then("^'Zip Code must have numeric characters only' alert message should display$")
	public void zip_Code_must_have_numeric_characters_only_alert_message_should_display() throws Throwable {
		String expectedAlertMessage="ZIP code must have numeric characters only";
		String actualAlertMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedAlertMessage, actualAlertMessage);
	}

	@When("^user is trying to submit request without entering email$")
	public void user_is_trying_to_submit_request_without_entering_email() throws Throwable {
		driver.switchTo().alert().dismiss();
		pageBean.setZip("12121");
		pageBean.setEmail("fdfsf");
		pageBean.clickSignUp();
	}

	@Then("^'You have entered an invalid email address!'$")
	public void you_have_entered_an_invalid_email_address() throws Throwable {
		String expectedAlertMessage="You have entered an invalid email address!";
		String actualAlertMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedAlertMessage, actualAlertMessage);
	}
	@When("^User is trying to submit request without entering valid 'gender'$")
	public void user_is_trying_to_submit_request_without_entering_valid_gender() throws Throwable {
		driver.switchTo().alert().dismiss();
		pageBean.setEmail("reyj.028@gmail.com");
		pageBean.clickSignUp();
	}

	@Then("^'Please Select gender' alert message should display$")
	public void please_Select_gender_alert_message_should_display() throws Throwable {
		String expectedAlertMessage="Please Select gender";
		String actualAlertMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedAlertMessage, actualAlertMessage);
		
	}

	@When("^User is trying to submit request after entering valid set of information$")
	public void user_is_trying_to_submit_request_after_entering_valid_set_of_information() throws Throwable {
		String[] languages= {"English","Non English"};
		pageBean.setUserId("shrey1234");
		pageBean.setUsername("shreyansh");
		pageBean.setPassword("hellorey");
		pageBean.setAddress("shreyansjain");
		pageBean.setCountry("India");
		pageBean.setZip("12121");
		pageBean.setEmail("reyj.028@gmail.com");
		pageBean.setGender("Male");
		pageBean.setLanguages(languages);
		pageBean.clickSignUp();
	}

	@Then("^'Your registration has successfully done'$")
	public void your_registration_has_successfully_done() throws Throwable {
		String expectedAlertMessage="Your Registration with JobsWorld.com has successfully done plz check your registred email addres to activate your profile";
		String actualAlertMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedAlertMessage, actualAlertMessage);

	}

	@After
	public void tearDownStepEnv() {
		driver.switchTo().alert().dismiss();
		driver.close();
	}
}
